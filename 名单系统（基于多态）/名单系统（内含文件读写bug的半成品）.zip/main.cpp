#include<iostream>
#include"AClass.h"
#include "SCPsystem.h"
using namespace std;

//bug��SCPsystem::archive����
int main()
{
	SCPsystem sys;
	sys.archive << "123189236" << endl;
	return 0;
}