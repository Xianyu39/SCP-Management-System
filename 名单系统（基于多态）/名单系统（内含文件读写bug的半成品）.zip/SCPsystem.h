#ifndef SCPSYSTEM_H_
#define SCPSYSTEM_H_
#include<list>
#include<fstream>
#include"Personnel.h"
using namespace std;

class SCPsystem
{
public:
	list<Personnel*> personnel_list;//Basic data structure.
	mutable fstream archive;//Save the file.

public:
	SCPsystem();
	~SCPsystem();
	void save()const;
};
#endif // !SCPSYSTEM_H_