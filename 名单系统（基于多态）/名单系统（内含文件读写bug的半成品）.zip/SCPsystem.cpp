#include "SCPsystem.h"
#include<iterator>
#include"AClass.h"

SCPsystem::SCPsystem()
	:archive("Data.txt",ios::in|ios::out),
	personnel_list(1)
{
	if (!archive.is_open())//Fail to open file.
	{
		cout << "Fail to access the dist." << endl;
		return;
	}

	char temp;
	archive >> temp;
	if (archive.eof())//is Empty, create an default Administor.
	{
		list<Personnel*>::iterator it = personnel_list.begin();
		(*it) = new AClass("001"s, "Administor"s, "001001001");
		cout << "Welcom to SCP, I believe you are the first User." << endl
			<< "Your account is:" << endl;
		(*it)->print();
		cout << "You can modify your message if you like." << endl;
	}
}

SCPsystem::~SCPsystem()
{
	save();

	for (auto& p : personnel_list)
	{
		if (p)
			delete p;
		p = nullptr;
	}
	archive.close();
}

void SCPsystem::save() const
{
	for (auto& each : personnel_list)
	{
		archive << each->ID << endl
				<< each->name << endl
				<< static_cast<char>(each->lev) << endl
				<< each->password << endl;
	}
}
