#include"Personnel.h"
#include<iostream>
#include<conio.h>

Personnel::Personnel(const string& ID, const string& name, Level lev, const string& password)
	:ID(ID),
	name(name),
	lev(lev),
	password(password), 
	overview(getLevelOverviewFileName(lev), ios_base::in)
{}

void Personnel::print(ostream& os) const
{
	//Basic information
	os  << ID << endl
		<< "Name: " << name << endl
		<< "Class Level: " << static_cast<char>(lev) << endl;
	os << "Press 'S' to get more information." << endl;

	//get Overview
	char ch = _getch();
	if (ch == 's' || ch == 'S')//Show information
	{
		string buffer;
		if (!overview.is_open() || !overview)//Exception handling
		{
			cout << "Something unexpected has occured, cannot get the information." << endl;
			return;
		}
		while (!overview.eof())
		{
			overview >> buffer;
			cout << buffer;
		}
	}
}
string Personnel::getLevelOverviewFileName(Level lev)
{
	switch (lev)
	{
	case Personnel::Level::A:
		return "Alevel.txt"s;
		break;
	case Personnel::Level::B:
		return "Blevel.txt"s;
		break;
	case Personnel::Level::C:
		return "Clevel.txt"s;
		break;
	case Personnel::Level::D:
		return "Dlevel.txt"s;
		break;
	case Personnel::Level::E:
		return "Elevel.txt"s;
		break;
	default:
		return "Something wrong happend...";
		break;
	}
}